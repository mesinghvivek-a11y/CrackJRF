# CrackJRF Admin + Student Workspace Build v2

This patch adds the first usable Admin workspace modules in this order: Dashboard, Excel Import Centre, Question Bank, and Syllabus. It also adds Manager, Settings and Role pages, and updates the student topic-test navigator.

## Included changes

- Seven Admin navigation sections: Dashboard, Excel Import Centre, Question Bank, Syllabus, Manager, Settings and Role.
- Dashboard reads live resource counts from Supabase; it contains status information only, not duplicate shortcut cards.
- Excel template v5 retains English/Hindi question and option columns and Hindi explanation. Hindi is optional; incomplete or absent Hindi does not block English import. June, December, January and Other are in the session dropdown.
- December exam-cycle metadata remains separate from the actual `exam_date`, so a December cycle held in January is not re-labelled as a January session.
- Question Bank includes question/keyword search within the latest 1,000 records returned by the initial list API, exam metadata filters, select-visible, role-gated delete and bulk reclassification within one subject taxonomy. A fully server-paginated search across every historical row remains a follow-up improvement.
- Syllabus displays Subject → Unit → Section → Topic → Subtopic, exact per-node counts via an RPC, expandable rows and Super Admin-only add/edit controls.
- Student live test: five-column question palette on the right on desktop; answered/marked/unanswered states; Previous and Next on opposite bottom corners. After submission, the navigator shows green correct, red incorrect and grey skipped states; answer correctness is not exposed during the live test.
- Migration 0005 adds platform settings, atomic bulk question operations, exact syllabus count RPC and an updated trusted batch publishing function accepting January and optional/partial Hindi fields.

## Apply the patch in Codespaces

1. Upload this ZIP into the repository workspace (or place it where the Codespaces terminal can read it).
2. Extract it outside the repository, for example:

   ```bash
   unzip -o CrackJRF_Admin_Student_Workspace_Build_v2.zip -d /tmp/CrackJRF_Admin_Student_Workspace_Build_v2
   ```

3. From the CrackJRF repository root, run:

   ```bash
   bash /tmp/CrackJRF_Admin_Student_Workspace_Build_v2/apply_patch.sh
   ```

   The script backs up any overwritten files to a temporary directory and copies only the files listed in `files.txt`.

4. In Supabase Dashboard → SQL Editor, run the complete file `supabase/migrations/0005_admin_workspace_management.sql` from the project. Migration 0004 is already part of the previous build and should not be run again.
5. Return to the Codespaces terminal and run:

   ```bash
   npm run build:admin
   ```

   Then:

   ```bash
   npm run build:student
   ```

6. If both pass, inspect the changed files and commit only the source changes:

   ```bash
   git status --short
   git diff --check
   git add apps/admin apps/student packages/shared/src/index.ts public/templates/CrackJRF_Question_Import_Template_v5.xlsx supabase/migrations/0005_admin_workspace_management.sql
   git commit -m "Build CrackJRF admin workspace and test navigator"
   git push
   ```

Do not add `.env` files, service-role keys, backup archives or temporary ZIPs to Git.

## Validation performed for this patch artifact

- 56 TypeScript/TSX files in the reconstructed source snapshot passed TypeScript transpilation/syntax validation.
- Template v5 passed ZIP integrity validation; all six Hindi columns and the January session data validation are present.
- A full Next.js production build was not possible in the artifact-preparation environment because the extracted source had no `node_modules` and `next` was unavailable. Run the two production builds in your existing Codespace before pushing.
- Migration 0005 has not been run against your live Supabase database in this environment. Run it in SQL Editor and check its result before testing import or Admin features.
