#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "$ROOT" ]]; then
  echo "Run this script from inside the CrackJRF Git repository."
  exit 1
fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_DIR="$SCRIPT_DIR/patch"
BACKUP_DIR="$(mktemp -d "${TMPDIR:-/tmp}/crackjrf-workspace-backup.XXXXXX")"
while IFS= read -r rel || [[ -n "$rel" ]]; do
  [[ -z "$rel" ]] && continue
  target="$ROOT/$rel"
  source="$PATCH_DIR/$rel"
  if [[ -f "$target" ]]; then
    mkdir -p "$BACKUP_DIR/$(dirname "$rel")"
    cp "$target" "$BACKUP_DIR/$rel"
  fi
  mkdir -p "$(dirname "$target")"
  cp "$source" "$target"
done < "$SCRIPT_DIR/files.txt"
echo "Patch applied to: $ROOT"
echo "Previous versions of overwritten files were backed up to: $BACKUP_DIR"
echo "Next: apply supabase/migrations/0005_admin_workspace_management.sql in Supabase SQL Editor."
