# UGC NET Prep Platform

Monorepo starter for a multi-subject UGC NET preparation product, with Geography (Paper II, subject code 80) as the first subject and Paper I (code 00) represented as a separate shared subject/module.

## What is included

- `apps/student`: student-facing Next.js app (PYQ browsing, answer reveal, bookmarks, practice/full mock test flows, personal performance, static PYQ analytics and authentication).
- `apps/admin`: separate private Next.js admin app (dashboard, Excel Import Centre, editable import staging, bilingual/Hinglish review workspace, rich explanation and media editor, question bank, syllabus viewer, roles/settings).
- `packages/shared`: shared TypeScript models, test blueprints, demo data and expanded Geography/Paper I syllabus JSON.
- `supabase/migrations`: PostgreSQL schema, row-level security, private storage buckets, controlled answer reveal RPC, admin roles and test data tables.
- `scripts/seed-syllabus.ts`: seeds subjects, syllabus versions/nodes and initial test blueprints.

The repository is an implementation foundation with Supabase-backed API paths where credentials are configured. It does not contain the real 2014–2026 question dataset, and the demo questions are synthetic. The approved ingestion boundary is one consolidated `.xlsx` workbook per exam event/shift. The external AI/vendor prepares the workbook from official and institution source PDFs; CrackJRF does not perform PDF OCR, segmentation or solved-paper matching. Imported rows remain private until question review, syllabus classification, answer verification and Super Admin approval. Dependency installation, a production build, SQL execution and end-to-end Supabase verification must be completed in your environment before launch.

## Requirements

- Node.js 20.9 or later (Node 22 recommended).
- npm 10+.
- A Supabase project for shared auth, PostgreSQL and private file storage.

## 1. Install dependencies

From the repository root:

```bash
npm install
```

## 2. Configure Supabase

Create a Supabase project. Copy `.env.example` to each app:

```bash
cp .env.example apps/student/.env.local
cp .env.example apps/admin/.env.local
```

Fill these values in both app files:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

For syllabus seeding, also create a root `.env.local` with:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_KEY
```

**Never put `SUPABASE_SERVICE_ROLE_KEY` in either app's `NEXT_PUBLIC_` variables or browser code. Never commit `.env.local`.** The service role key bypasses RLS and is only needed by trusted server/admin scripts.

### Apply the database migration

Run `supabase/migrations/0001_initial_schema.sql` in the Supabase SQL Editor first, then `0002_json_import_packages.sql` if it has not already been applied, and finally `0003_excel_import_workflow.sql`. Migration 0002 is retained for compatibility with the earlier JSON intake; migration 0003 adds Excel staging, Hindi/Hinglish script variants, review metadata, keywords and Student Portal visibility safeguards. Do not rerun earlier migrations on an already-migrated database.

Then seed the subject and syllabus rows:

```bash
npm run seed:syllabus
```

The seed contains the ten Geography units and ten Paper I units based on the PDFs supplied in this project. Finer sections and subtopics are organizational expansions; they should be reviewed before bulk question tagging.

### Create the first Super Admin

1. Register your own account through Supabase Auth (email/password).
2. Find its UUID in Supabase Authentication → Users.
3. Run this SQL, replacing the email:

```sql
insert into public.admin_members(user_id, role, active)
select id, 'super_admin', true
from auth.users
where email = 'YOUR_ADMIN_EMAIL'
on conflict (user_id) do update set role = 'super_admin', active = true;
```

The admin frontend checks `public.is_admin()` and the database policies enforce authorization. The admin URL itself is not a security control.

### Configure authentication

In Supabase Authentication → URL Configuration, add local redirect URLs for both apps, for example:

- `http://localhost:3000/**`
- `http://localhost:3001/**`

Enable Email/Password. To use Google, configure Google OAuth credentials in Google Cloud and add them to Supabase Auth → Providers → Google. The student app has email/password and Google OAuth sign-in buttons. The admin app currently has email/password sign-in; use a separately designated administrator account.

## 3. Run both applications

Open two terminals at the repository root:

```bash
npm run dev:student
```

Student app: <http://localhost:3000>

```bash
npm run dev:admin
```

Admin app: <http://localhost:3001>

Without Supabase environment values, both apps open in clearly labelled local preview mode. Admin changes then remain local in the browser and uploads/publishing are not persisted.

## 4. Excel-first question import workflow

The provider delivers **one `.xlsx` workbook per examination event/shift**. Paper I and Paper II for that event are placed in the same `Questions` worksheet, with one logical question per row. The workbook contains:

- `Exam Metadata`: year, June/December/other session, date, shift, event type, Paper II subject code and source filenames (entered once).
- `Questions`: English question and four options, proposed answer/explanation, official/institution source page references, suggested syllabus IDs, optional official Hindi, optional Hindi/Hinglish drafts, keywords and media notes.
- `Geography Taxonomy` and `Paper I Taxonomy`: the current CrackJRF tagging hierarchy; use exact stable IDs.
- `Lists` and `Column Guide`: allowed values and field descriptions.

Download the current template from Admin → Excel Import Centre or use [`public/templates/CrackJRF_Question_Import_Template_v2.xlsx`](public/templates/CrackJRF_Question_Import_Template_v2.xlsx). The workbook is deliberately a single-file handoff: no separate manifest, JSON language files, checksum file or media folder is required. Source PDFs remain in the provider's source archive. Put source filenames and page numbers in the workbook; attach actual diagrams/maps/page crops to the question or explanation from the editable Admin staging screen.

### Provider source rules

The official bilingual paper controls the original question text, options, order and original question number. Institution solved papers provide proposed answers and explanations. Official final/revised answer keys override provisional or institution answers. The provider must record source type/title/page, question-match status/confidence and unresolved QA issues. Never infer that an institutional answer is official. Do not invent missing options, explanations, translations, diagrams or classifications. Use exact `unit_id`, `section_id`, `topic_id` and `subtopic_id` from the supplied taxonomy sheets; leave uncertain classifications blank and flag them.

### Admin ingestion and review

Apply `0003_excel_import_workflow.sql` after migrations 0001 and 0002. In Admin → Excel Import Centre, upload the workbook. The browser uploads the file into private storage; the server validates the workbook and stages each question row. Open a batch to correct English text/options, optional Hindi and Hinglish, explanations, tags and source references. Generate Hindi/Hinglish translations only as drafts using the configured Gemini API; existing official or manually edited text is not overwritten automatically.

A Reviewer or Super Admin must mark a row reviewed before it can be promoted to the canonical Question Bank as a **draft**. Promotion generates platform-owned question and option IDs; it does not publish. Proposed answers are saved only as unverified answer evidence. The canonical Question Review workspace is where the English/Hindi/Hinglish fields, option translations, answer evidence, syllabus hierarchy, explanation translations and assets receive their final editorial review. Hindi and Hinglish question/option translations are separately hidden from students until marked reviewed. Hindi/Hinglish explanations are separately hidden until their explanation review status is verified. Only the Super Admin can approve and publish a question; the answer must be verified (or explicitly dropped) first.

The Admin translation draft endpoint uses the Gemini API. Configure `GEMINI_API_KEY` and `GEMINI_MODEL` as server-only Admin environment variables. Never expose either as `NEXT_PUBLIC_*`. If translation is not configured, all manual editing/import functions still work.

The legacy JSON package tables and routes are retained during migration only. They are not the recommended new content handoff. Do not delete the old JSON migration/tables until the Excel workflow has passed an end-to-end production test.

See [`docs/EXCEL_IMPORT_WORKFLOW.md`](docs/EXCEL_IMPORT_WORKFLOW.md) for field mapping, workflow permissions, translation safeguards, media handling and test steps.

## 5. Question identity and content rules

- Use platform-owned canonical IDs (e.g. `GEO-Q-000001`, `P1-Q-000001`).
- Preserve NTA's question ID as optional source metadata, never as the primary key.
- Preserve each exam appearance separately (year, June/December/other, re-exam/special, paper, date, shift and original question number).
- English and Hindi are language variants of one canonical logical question, not separate question records. Preserve the external language-specific question codes ending in `E` and `H` on the language records.
- Provider option IDs remain stable across language files and are mapped to platform-owned option UUIDs; A/B/C/D remain the visible option keys.
- A question can map to multiple units/topics, but overall unique-question totals and test selection must deduplicate by canonical question ID.
- Shared passages, tables and stimuli use question groups so related sub-questions can point to the same stimulus.
- Keep official and private source records separate. Preserve the provider's question-match provenance; a provider match is not answer verification and CrackJRF does not independently match solved-paper content.
- An answer claim from a private source is not verified until reviewed. Keep disputed answer evidence and references.
- Do not publish a question with a pending or disputed answer into a scored test. Handle dropped/multiple-correct questions with explicit grading rules.
- Historical papers retain their actual question counts/patterns. New complete mock blueprints use 50 Paper I + 100 Paper II questions over 180 minutes. Geography-only 100-question/120-minute mode is a platform practice configuration, not an official separate Paper II time allotment.

## 6. Main routes

### Student (`localhost:3000`)

- `/` – overview
- `/pyq` – published question browsing, filters, answer reveal and bookmarks
- `/tests` – Geography-only, full UGC NET and custom timed CBT; test attempts require enough verified, published questions
- `/analytics` – PYQ frequency and historical trend analysis from source appearances
- `/performance` – personal performance derived from completed attempts
- `/revision` – bookmarks and mistake notebook entry point
- `/auth` – email/password and Google OAuth UI

### Admin (`localhost:3001`)

- `/` – admin dashboard
- `/imports` – single Excel workbook upload, validation and import history
- `/imports/excel/[batchId]` – editable question-by-question staging and draft promotion
- `/review` – three-panel review/editor workspace with rich explanation editor
- `/questions` – question bank management shell
- `/syllabus` – Geography and Paper I taxonomy viewer
- `/settings` – roles/security guidance
- `/auth` – admin sign in

## 7. Validation helpers

```bash
npm run validate:question -- examples/question-record.example.json
```

This validates structural fields only. It does not verify source authenticity, taxonomy correctness, translations, or answer correctness.

## 8. Important production work remaining

Before real candidates use the platform:

1. Complete canonical-question promotion from package staging, including safe retries, provenance links and language-specific external question codes.
2. Verify question revision snapshots and approval actions with real Supabase accounts and RLS.
3. Test the student CBT client against the server-authoritative `start_test_attempt`, response-save, `submit_test_attempt` and post-submit review RPCs. Never let the browser submit or read test answer keys.
4. Test the student PYQ reveal interface against the `get_practice_answer` RPC and active-test access checks.
5. Replace remaining demo data with reviewed, licensed content; validate student library and dashboard queries.
6. Complete the bilingual content review and explanation workflow without overwriting independently edited Hindi.
7. Add import correction/supersession tools, resilient batch recovery and a full audit trail for large vendor deliveries.
8. Run security review, RLS tests, accessibility checks, load tests and production backups.

This repository is a runnable foundation and first-pass interface, not a claim that the entire production product or the 2014–2026 dataset is already complete.

## 9. Pilot validation

The older [`docs/PILOT_VALIDATION.md`](docs/PILOT_VALIDATION.md) document records a historical PDF/OCR workflow test. That workflow is retired; the current vendor handoff is one Excel workbook per exam event/shift.

## Student website link

Set `NEXT_PUBLIC_STUDENT_APP_URL` in the Admin deployment to the real Student Portal URL. The local development default remains `http://localhost:3000`.
